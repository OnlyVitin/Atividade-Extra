public class Pessoa {
    private String nome;
    private int CPF;
    private int idade;
    private char sexo;
    private Endereco end;

    public Pessoa (){
        this.end = new Endereco();
    }

    public Pessoa(String Nome, int CPF, int idade, char sexo){
        this.nome = nome;
        this.CPF = CPF;
        this.idade = idade;
        this.sexo = sexo;
        this.end = new Endereco();
    }

    public Pessoa(String Nome, int CPF, int idade, char sexo, Endereco end){
        this.nome = nome;
        this.CPF = CPF;
        this.idade = idade;
        this.sexo = sexo;
        this.end = end;
    }

    //metodos de acesso
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCPF() {
        return CPF;
    }

    public void setCPF(int CPF) {
        this.CPF = CPF;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public Endereco getEnd() {
        return end;
    }

    public void setEnd(Endereco end) {
        this.end = end;
    }

    public String imprimir(){
        return "\nNome: " + nome + "\nCPF: " + CPF + "\nIdade: " + idade + "\nSexo: "
                + sexo + end.imprimir();

    }
}
