public class Praca {
    private String Bancos;
    private String Postes;
    private String Brinquedos;
    private String Rampas;
    private String Escadas;
    private String Iluminacoes;
    private String Extra;



    public Praca(String Bancos, String Postes, String Brinquedos, String Rampas, String Iluminacoes, String Escadas, String Extra) {
        this.Bancos = Bancos;
        this.Postes = Postes;
        this.Brinquedos = Brinquedos;
        this.Rampas = Rampas;
        this.Iluminacoes = Iluminacoes;
        this.Escadas = Escadas;
        this.Extra = Extra;
    }

    public Praca() {

    }

    //metodos de acesso
    public String getBancos() {
        return Bancos;
    }

    public void setBancos(String bancos) {
        Bancos = bancos;
    }

    public String getPostes() {
        return Postes;
    }

    public void setPostes(String postes) {
        Postes = postes;
    }

    public String getBrinquedos() {
        return Brinquedos;
    }

    public void setBrinquedos(String brinquedos) {
        Brinquedos = brinquedos;
    }

    public String getRampas() {
        return Rampas;
    }

    public void setRampas(String rampas) {
        Rampas = rampas;
    }

    public String getEscadas() {
        return Escadas;
    }

    public void setEscadas(String escadas) {
        Escadas = escadas;
    }

    public String getIluminacoes() {
        return Iluminacoes;
    }

    public void setIluminacoes(String iluminacoes) {
        Iluminacoes = iluminacoes;
    }

    public String getExtra() {
        return Extra;
    }

    public void setExtra(String extra) {
        Extra = extra;
    }

    public String imprimir(){
        return "Bancos" + Bancos + "\nPostes:" + Postes + "\nBrinquedos:" + Brinquedos + "\nRampas: " + Rampas
                + "\nEscadas: " + Escadas + "\nIluminação: " + Iluminacoes + "\nOutros: " + Extra;
    }

}

