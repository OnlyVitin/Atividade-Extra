import java.util.Scanner;

public class EnderecoPessoa {
    public static void main(String[] args){
        Scanner entrada = new Scanner(System.in);
        Scanner entradaString = new Scanner(System.in);

        char resp;

        Pessoa p = new Pessoa();
        Endereco end = new Endereco();

        System.out.println("Digite seu nome: ");
        p.setNome(entradaString.nextLine());
        System.out.println("Digite seu CPF: ");
        p.setCPF(entrada.nextInt());
        System.out.println("Digite sua idade:");
        p.setIdade(entrada.nextInt());
        System.out.println("Digite seu sexo (FEM/MAS):");
        p.setSexo(entrada.next().charAt(0));
        System.out.println("Digite seu endereço:");
        end.setLogradouro(entradaString.nextLine());
        System.out.println("Digite o numero: ");
        end.setNumero(entrada.nextInt());

        System.out.println("Tem complemento?");
        resp = entrada.next().charAt(0);

        if(resp == 's'){
            System.out.println("Digite o complemento: ");
            end.setComplemento(entradaString.nextLine());
        }else {
            end.setComplemento("");
        }

        System.out.println("Digite o CEP:");
        end.setCEP(entrada.nextInt());
        System.out.println("Digite sua cidade: ");
        end.setCidade(entradaString.nextLine());
        System.out.println("Digite seu estado");
        end.setEstado(entradaString.nextLine());


        p.setEnd(end);

        System.out.println("Dados Cadastrais" + p.imprimir());

        Praca praca = new Praca();

        System.out.println("=========================");



        System.out.println("Possui bancos quebrados? (S/N)");
        resp = entrada.next().charAt(0);

        if(resp == 's'){
            System.out.println("Quantidade de bancos quebrados: ");
            praca.setBancos(entradaString.nextLine());
        }else {
            praca.setBancos("");
        }

        System.out.println("Possui bancos Postes? (S/N)");
        resp = entrada.next().charAt(0);

        if(resp == 's'){
            System.out.println("Quantidade de bancos quebrados: ");
            praca.setPostes(entradaString.nextLine());
        }else {
            praca.setPostes("");
        }

        System.out.println("Possui Brinquedos quebrados? (S/N)");
        resp = entrada.next().charAt(0);

        if(resp == 's'){
            System.out.println("Quantidade de brinquedos quebrados: ");
            praca.setBrinquedos(entradaString.nextLine());
        }else {
            praca.setBrinquedos("");
        }

        System.out.println("Possui rampas quebrados? (S/N)");
        resp = entrada.next().charAt(0);

        if(resp == 's'){
            System.out.println("Quantidade de rampas quebradas: ");
            praca.setRampas(entradaString.nextLine());
        }else {
            praca.setRampas("");
        }

        System.out.println("Possui Escadas quebrados? (S/N)");
        resp = entrada.next().charAt(0);

        if(resp == 's'){
            System.out.println("Quantidade de Escadas quebrados: ");
            praca.setEscadas(entradaString.nextLine());
        }else {
            praca.setEscadas("");
        }

        System.out.println("Possui iluminações quebradas? (S/N)");
        resp = entrada.next().charAt(0);

        if(resp == 's'){
            System.out.println("Quantidade de iluminações quebradas: ");
            praca.setIluminacoes(entradaString.nextLine());
        }else {
            praca.setIluminacoes("");
        }

        System.out.println("Possui algum outro item quebrado?");
        resp = entrada.next().charAt(0);

        if(resp == 's'){
            System.out.println("Qual item que não esta na lista esta quebrado? ");
            praca.setExtra(entradaString.nextLine());
        }else {
            praca.setExtra("");
        }


        System.out.println("\nCheck List\n" + praca.imprimir());

    }

   }


